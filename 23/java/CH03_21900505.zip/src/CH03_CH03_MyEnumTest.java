

public class CH03_CH03_MyEnumTest {
	public static void main(String[] args)
	{
		String[] Weeks = {"MON", "TUE", "WED","THR","FRI","SAT","SUN"};
		for (int i = 0; i < Weeks.length; i++)
		{
			System.out.println(Weeks[i]+"day!");
		}
	}
}
